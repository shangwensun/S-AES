
"""
PyQt5 GUI for Simplified AES (S-AES) — 16-bit block, 16-bit key.

Features (for the assignment 第1关 + 第3关):
- 16-bit 加/解密（输入支持 HEX/BIN/ASCII 三种模式，内部统一为 16-bit 块处理）
- ASCII 任意长度（自动以 2 bytes 为一块处理，ECB + PKCS#7(到 2 字节) padding）
- 可视化展示：每一轮子步骤可在“日志”面板中输出（可选）
- 结果同时显示为 HEX/BIN/ASCII

参考教材《密码编码学与网络安全——原理与实践(第8版)》附录D：简化AES（S-AES）。
"""

import sys
from PyQt5 import QtWidgets, QtCore

# ------------------------- S-AES Core -------------------------

# GF(2^4) with irreducible polynomial x^4 + x + 1 => 0b1_0011 (0x13)
IRREDUCIBLE = 0x13

# 4-bit S-box (从 S-AES 标准；表 D.x)
SBOX = [
    0x9, 0x4, 0xA, 0xB,
    0xD, 0x1, 0x8, 0x5,
    0x6, 0x2, 0x0, 0x3,
    0xC, 0xE, 0xF, 0x7
]

INV_SBOX = [
    0xA, 0x5, 0x9, 0xB,
    0x1, 0x7, 0x8, 0xF,
    0x6, 0x0, 0x2, 0x3,
    0xC, 0x4, 0xD, 0xE
]

# MixColumns matrices over GF(2^4)
# Forward: [[1,4],[4,1]]  ; Inverse: [[9,2],[2,9]]
MC_MAT = ((1, 4), (4, 1))
IMC_MAT = ((9, 2), (2, 9))

# Rcon for key schedule (8-bit values for the byte-wise schedule)
RCON1 = 0x80  # 1000_0000
RCON2 = 0x30  # 0011_0000


def gf4_mul(a, b):
    """Multiply two 4-bit elements in GF(2^4) with modulus x^4 + x + 1 (0x13)."""
    res = 0
    aa = a & 0xF
    bb = b & 0xF
    for _ in range(4):
        if bb & 1:
            res ^= aa
        bb >>= 1
        carry = aa & 0x8
        aa = ((aa << 1) & 0xF)
        if carry:
            aa ^= 0x3  # because x^4 == x + 1 -> reduce with 0b0011
    return res & 0xF


def sub_nibbles(byte):
    """Apply SBOX to high and low nibble of an 8-bit value."""
    hi = SBOX[(byte >> 4) & 0xF]
    lo = SBOX[byte & 0xF]
    return (hi << 4) | lo


def inv_sub_nibbles(byte):
    hi = INV_SBOX[(byte >> 4) & 0xF]
    lo = INV_SBOX[byte & 0xF]
    return (hi << 4) | lo


def rotate_nibbles(byte):
    """Swap high/low nibble: ab -> ba."""
    return ((byte & 0xF) << 4) | ((byte >> 4) & 0xF)


def key_schedule(key16):
    """
    Input: 16-bit key (int: 0..65535)
    Output: round keys K0, K1, K2 each 16-bit (tuple of ints)
    Follows S-AES schedule: w0,w1 -> w2..w5; K0=w0||w1, K1=w2||w3, K2=w4||w5
    """
    w0 = (key16 >> 8) & 0xFF
    w1 = key16 & 0xFF

    def g(word, rcon):
        x = rotate_nibbles(word)
        x = sub_nibbles(x)
        return x ^ rcon

    w2 = w0 ^ g(w1, RCON1)
    w3 = w2 ^ w1
    w4 = w2 ^ g(w3, RCON2)
    w5 = w4 ^ w3

    k0 = (w0 << 8) | w1
    k1 = (w2 << 8) | w3
    k2 = (w4 << 8) | w5
    return k0, k1, k2


def add_round_key(state16, key16):
    return state16 ^ key16


def state_to_matrix16(s):
    """
    Map 16-bit state -> 2x2 nibbles matrix (column-major like AES):
    [ s0 s2 ; s1 s3 ] where bytes are [b0,b1]=[s0|s1, s2|s3].
    """
    b0 = (s >> 8) & 0xFF
    b1 = s & 0xFF
    return [
        [ (b0 >> 4) & 0xF, (b1 >> 4) & 0xF ],
        [ b0 & 0xF,        b1 & 0xF       ],
    ]


def matrix_to_state16(m):
    b0 = ((m[0][0] & 0xF) << 4) | (m[1][0] & 0xF)
    b1 = ((m[0][1] & 0xF) << 4) | (m[1][1] & 0xF)
    return ((b0 & 0xFF) << 8) | (b1 & 0xFF)


def sub_nib(state16):
    b0 = (state16 >> 8) & 0xFF
    b1 = state16 & 0xFF
    return ((sub_nibbles(b0) << 8) | sub_nibbles(b1)) & 0xFFFF


def inv_sub_nib(state16):
    b0 = (state16 >> 8) & 0xFF
    b1 = state16 & 0xFF
    return ((inv_sub_nibbles(b0) << 8) | inv_sub_nibbles(b1)) & 0xFFFF


def shift_rows(state16):
    """
    2x2 state: second row circularly left shift by 1 nibble
    Before:
      [s0 s2]
      [s1 s3]
    After:
      [s0 s2]
      [s3 s1]
    """
    m = state_to_matrix16(state16)
    m[1][0], m[1][1] = m[1][1], m[1][0]
    return matrix_to_state16(m)


def inv_shift_rows(state16):
    return shift_rows(state16)  # for 2x2, inverse equals itself


def mix_columns(state16):
    m = state_to_matrix16(state16)
    res = [[0,0],[0,0]]
    for c in range(2):
        a0 = m[0][c]
        a1 = m[1][c]
        res[0][c] = (gf4_mul(MC_MAT[0][0], a0) ^ gf4_mul(MC_MAT[0][1], a1)) & 0xF
        res[1][c] = (gf4_mul(MC_MAT[1][0], a0) ^ gf4_mul(MC_MAT[1][1], a1)) & 0xF
    return matrix_to_state16(res)


def inv_mix_columns(state16):
    m = state_to_matrix16(state16)
    res = [[0,0],[0,0]]
    for c in range(2):
        a0 = m[0][c]
        a1 = m[1][c]
        res[0][c] = (gf4_mul(IMC_MAT[0][0], a0) ^ gf4_mul(IMC_MAT[0][1], a1)) & 0xF
        res[1][c] = (gf4_mul(IMC_MAT[1][0], a0) ^ gf4_mul(IMC_MAT[1][1], a1)) & 0xF
    return matrix_to_state16(res)


def saes_encrypt_block(p16, k16, log=None):
    K0, K1, K2 = key_schedule(k16)
    s = add_round_key(p16, K0)
    if log: log(f"AddRoundKey K0: {K0:04X} -> {s:04X}")

    s = sub_nib(s);       log and log(f"SubNib: {s:04X}") if log else None
    s = shift_rows(s);    log and log(f"ShiftRows: {s:04X}") if log else None
    s = mix_columns(s);   log and log(f"MixColumns: {s:04X}") if log else None
    s = add_round_key(s, K1); log and log(f"AddRoundKey K1: {K1:04X} -> {s:04X}") if log else None

    s = sub_nib(s);       log and log(f"SubNib: {s:04X}") if log else None
    s = shift_rows(s);    log and log(f"ShiftRows: {s:04X}") if log else None
    s = add_round_key(s, K2); log and log(f"AddRoundKey K2: {K2:04X} -> {s:04X}") if log else None
    return s & 0xFFFF


def saes_decrypt_block(c16, k16, log=None):
    K0, K1, K2 = key_schedule(k16)
    s = add_round_key(c16, K2); log and log(f"AddRoundKey K2: {K2:04X} -> {s:04X}")
    s = inv_shift_rows(s);      log and log(f"InvShiftRows: {s:04X}") if log else None
    s = inv_sub_nib(s);         log and log(f"InvSubNib: {s:04X}") if log else None

    s = add_round_key(s, K1);   log and log(f"AddRoundKey K1: {K1:04X} -> {s:04X}") if log else None
    s = inv_mix_columns(s);     log and log(f"InvMixColumns: {s:04X}") if log else None
    s = inv_shift_rows(s);      log and log(f"InvShiftRows: {s:04X}") if log else None
    s = inv_sub_nib(s);         log and log(f"InvSubNib: {s:04X}") if log else None

    s = add_round_key(s, K0);   log and log(f"AddRoundKey K0: {K0:04X} -> {s:04X}") if log else None
    return s & 0xFFFF

# ------------------------- Multi-Encryption (关4) -------------------------

def parse_key_bits(text: str, radix: str, total_bits: int) -> int:
    """Parse a key of arbitrary bit length (16/32/48) in HEX or BIN."""
    s = text.strip().replace(' ', '')
    if radix == 'HEX':
        v = int(s, 16)
    elif radix == 'BIN':
        v = int(s, 2)
    else:
        raise ValueError('密钥仅支持 HEX 或 BIN')
    max_val = (1 << total_bits) - 1
    if not (0 <= v <= max_val):
        raise ValueError(f'{total_bits} 位密钥范围错误 (0..{max_val:X})')
    return v


def split_to_16bit_keys(value: int, count: int) -> list:
    """Split a composite integer into `count` many 16-bit keys [K1, K2, ...]."""
    keys = []
    for i in range(count):
        shift = 16 * (count - 1 - i)
        keys.append((value >> shift) & 0xFFFF)
    return keys


def saes_double_encrypt_block(p16: int, k1: int, k2: int, log=None) -> int:
    """Double encryption: C = E_{K2}(E_{K1}(P))."""
    mid = saes_encrypt_block(p16, k1, log=None)
    if log: log(f"Double: E_K1 -> {mid:04X}")
    out = saes_encrypt_block(mid, k2, log=None)
    if log: log(f"Double: E_K2 -> {out:04X}")
    return out & 0xFFFF


def saes_double_decrypt_block(c16: int, k1: int, k2: int, log=None) -> int:
    """Double decryption: P = D_{K1}(D_{K2}(C))."""
    mid = saes_decrypt_block(c16, k2, log=None)
    if log: log(f"Double: D_K2 -> {mid:04X}")
    out = saes_decrypt_block(mid, k1, log=None)
    if log: log(f"Double: D_K1 -> {out:04X}")
    return out & 0xFFFF


def saes_triple_encrypt_block_2keys(p16: int, k1: int, k2: int, log=None) -> int:
    """Triple encryption (EDE, two keys): C = E_{K1}(D_{K2}(E_{K1}(P)))."""
    s1 = saes_encrypt_block(p16, k1, log=None)
    if log: log(f"Triple-2: E_K1 -> {s1:04X}")
    s2 = saes_decrypt_block(s1, k2, log=None)
    if log: log(f"Triple-2: D_K2 -> {s2:04X}")
    s3 = saes_encrypt_block(s2, k1, log=None)
    if log: log(f"Triple-2: E_K1 -> {s3:04X}")
    return s3 & 0xFFFF


def saes_triple_decrypt_block_2keys(c16: int, k1: int, k2: int, log=None) -> int:
    """Triple decryption (EDE, two keys)."""
    s1 = saes_decrypt_block(c16, k1, log=None)
    if log: log(f"Triple-2: D_K1 -> {s1:04X}")
    s2 = saes_encrypt_block(s1, k2, log=None)
    if log: log(f"Triple-2: E_K2 -> {s2:04X}")
    s3 = saes_decrypt_block(s2, k1, log=None)
    if log: log(f"Triple-2: D_K1 -> {s3:04X}")
    return s3 & 0xFFFF


def saes_triple_encrypt_block_3keys(p16: int, k1: int, k2: int, k3: int, log=None) -> int:
    """Triple encryption (EDE, three keys): C = E_{K1}(D_{K2}(E_{K3}(P)))."""
    s1 = saes_encrypt_block(p16, k3, log=None)
    if log: log(f"Triple-3: E_K3 -> {s1:04X}")
    s2 = saes_decrypt_block(s1, k2, log=None)
    if log: log(f"Triple-3: D_K2 -> {s2:04X}")
    s3 = saes_encrypt_block(s2, k1, log=None)
    if log: log(f"Triple-3: E_K1 -> {s3:04X}")
    return s3 & 0xFFFF


def saes_triple_decrypt_block_3keys(c16: int, k1: int, k2: int, k3: int, log=None) -> int:
    """Triple decryption (EDE, three keys)."""
    s1 = saes_decrypt_block(c16, k1, log=None)
    if log: log(f"Triple-3: D_K1 -> {s1:04X}")
    s2 = saes_encrypt_block(s1, k2, log=None)
    if log: log(f"Triple-3: E_K2 -> {s2:04X}")
    s3 = saes_decrypt_block(s2, k3, log=None)
    if log: log(f"Triple-3: D_K3 -> {s3:04X}")
    return s3 & 0xFFFF


def encrypt_with_scheme(p16: int, keys: list, scheme: str, log=None) -> int:
    """Dispatch encrypt by scheme: single/double/triple2/triple3."""
    if scheme == 'single':
        return saes_encrypt_block(p16, keys[0], log=log)
    elif scheme == 'double':
        return saes_double_encrypt_block(p16, keys[0], keys[1], log=log)
    elif scheme == 'triple2':
        return saes_triple_encrypt_block_2keys(p16, keys[0], keys[1], log=log)
    elif scheme == 'triple3':
        return saes_triple_encrypt_block_3keys(p16, keys[0], keys[1], keys[2], log=log)
    else:
        raise ValueError('未知加密方案')


def decrypt_with_scheme(c16: int, keys: list, scheme: str, log=None) -> int:
    """Dispatch decrypt by scheme: single/double/triple2/triple3."""
    if scheme == 'single':
        return saes_decrypt_block(c16, keys[0], log=log)
    elif scheme == 'double':
        return saes_double_decrypt_block(c16, keys[0], keys[1], log=log)
    elif scheme == 'triple2':
        return saes_triple_decrypt_block_2keys(c16, keys[0], keys[1], log=log)
    elif scheme == 'triple3':
        return saes_triple_decrypt_block_3keys(c16, keys[0], keys[1], keys[2], log=log)
    else:
        raise ValueError('未知解密方案')


# ------------------------- CBC (关5) -------------------------

def cbc_encrypt_blocks(plain_blocks, keys: list, scheme: str, iv16: int, log=None):
    """Encrypt a sequence of 16-bit blocks using CBC."""
    out = []
    prev = iv16 & 0xFFFF
    for p in plain_blocks:
        x = p ^ prev
        c = encrypt_with_scheme(x & 0xFFFF, keys, scheme, log=None)
        if log:
            log(f"CBC: XOR prev {prev:04X} -> {x & 0xFFFF:04X}, ENC -> {c:04X}")
        out.append(c & 0xFFFF)
        prev = c & 0xFFFF
    return out


def cbc_decrypt_blocks(cipher_blocks, keys: list, scheme: str, iv16: int, log=None):
    """Decrypt a sequence of 16-bit blocks using CBC."""
    out = []
    prev = iv16 & 0xFFFF
    for c in cipher_blocks:
        x = decrypt_with_scheme(c & 0xFFFF, keys, scheme, log=None)
        p = (x ^ prev) & 0xFFFF
        if log:
            log(f"CBC: DEC {c & 0xFFFF:04X} -> {x & 0xFFFF:04X}, XOR prev {prev:04X} -> {p:04X}")
        out.append(p)
        prev = c & 0xFFFF
    return out


# ------------------------- MITM for Double Encryption -------------------------

def meet_in_the_middle_double(p16: int, c16: int, log=None):
    """Return list of candidate (K1,K2) s.t. E_{K2}(E_{K1}(P)) == C."""
    if log: log("MITM: 构建 E_{K1}(P) 表 (2^16 键)...")
    table = {}
    for k1 in range(0x10000):
        mid = saes_encrypt_block(p16, k1, log=None)
        table.setdefault(mid, []).append(k1)
    if log: log("MITM: 扫描 D_{K2}(C) 并匹配 (2^16 键)...")
    results = []
    for k2 in range(0x10000):
        mid = saes_decrypt_block(c16, k2, log=None)
        ks = table.get(mid)
        if ks:
            for k1 in ks:
                results.append((k1, k2))
    if log: log(f"MITM: 候选数量 {len(results)}。建议使用第二个明密文对进一步筛选。")
    return results

def meet_in_the_middle_double_multi(pairs, log=None):
    """联合筛选：使用第一个(P,C)对做MITM，再用其余(P,C)对验证候选。"""
    if not pairs:
        return []
    p0, c0 = pairs[0]
    if log: log("MITM: 使用第一个对生成初始候选...")
    candidates = meet_in_the_middle_double(p0, c0, log=log)
    if len(pairs) == 1:
        return candidates
    if log: log(f"MITM: 初始候选 {len(candidates)}，使用其余 {len(pairs)-1} 个对验证...")
    filtered = []
    for (k1, k2) in candidates:
        ok = True
        for (p, c) in pairs[1:]:
            if saes_double_encrypt_block(p, k1, k2, log=None) != c:
                ok = False
                break
        if ok:
            filtered.append((k1, k2))
    if log: log(f"MITM: 联合筛选后剩余 {len(filtered)} 候选。")
    return filtered


# ------------------------- Helpers for UI -------------------------

def pkcs7_pad_2bytes(b: bytes) -> bytes:
    """Pad to multiple of 2 bytes (block = 2). PKCS#7-like. pad of 1 or 2 bytes."""
    rem = len(b) % 2
    pad = 2 if rem == 0 else 1
    return b + bytes([pad]) * pad


def pkcs7_unpad_2bytes(b: bytes) -> bytes:
    if not b:
        return b
    pad = b[-1]
    if pad in (1, 2) and len(b) >= pad and all(x == pad for x in b[-pad:]):
        return b[:-pad]
    return b


def blocks16_from_bytes(b: bytes):
    """Yield 16-bit ints from bytes (big endian)."""
    for i in range(0, len(b), 2):
        hi = b[i]
        lo = b[i + 1]
        yield (hi << 8) | lo


def bytes_from_blocks16(blocks):
    arr = bytearray()
    for s in blocks:
        arr.append((s >> 8) & 0xFF)
        arr.append(s & 0xFF)
    return bytes(arr)


def parse_block16(text: str, radix: str) -> int:
    s = text.strip().replace(' ', '')
    if radix == 'HEX':
        return int(s, 16) & 0xFFFF
    elif radix == 'BIN':
        return int(s, 2) & 0xFFFF
    else:
        raise ValueError('Only HEX/BIN supported for single-block input')


def format_block16(v: int, radix: str) -> str:
    if radix == 'HEX':
        return f"{v:04X}"
    elif radix == 'BIN':
        return f"{v:016b}"
    else:
        return ""

# ------------------------- PyQt5 GUI -------------------------

class SAESWindow(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("S-AES 教学工具（16-bit） — PyQt5")
        self.resize(820, 640)

        # Inputs
        self.keyEdit = QtWidgets.QLineEdit("3A94")  # 示例
        self.keyMode = QtWidgets.QComboBox()
        self.keyMode.addItems(["HEX", "BIN"])
        # 新增：加密类型（单/双/三重）
        self.encMode = QtWidgets.QComboBox()
        self.encMode.addItems(["单重(16-bit)", "双重(32-bit)", "三重EDE-2键(32-bit)", "三重EDE-3键(48-bit)"])

        self.inputText = QtWidgets.QPlainTextEdit()
        self.inputText.setPlaceholderText("明文/密文输入（HEX / BIN / ASCII）")

        self.inputMode = QtWidgets.QComboBox()
        self.inputMode.addItems(["HEX-单块(16bit)", "BIN-单块(16bit)", "ASCII-多块(ECB,2B)", "ASCII-多块(CBC,2B)"])

        # CBC 需要 IV
        self.ivEdit = QtWidgets.QLineEdit("0000")
        self.ivMode = QtWidgets.QComboBox()
        self.ivMode.addItems(["HEX", "BIN"])
        self.ivGenBtn = QtWidgets.QPushButton("生成随机IV")

        # Buttons
        self.encryptBtn = QtWidgets.QPushButton("加密 ▶")
        self.decryptBtn = QtWidgets.QPushButton("解密 ◀")

        # Output
        self.outputHex = QtWidgets.QLineEdit()
        self.outputBin = QtWidgets.QLineEdit()
        self.outputAscii = QtWidgets.QPlainTextEdit()
        self.outputAscii.setFixedHeight(80)

        # Log
        self.verbose = QtWidgets.QCheckBox("显示子步骤日志")
        self.logBox = QtWidgets.QPlainTextEdit()
        self.logBox.setReadOnly(True)
        self.logBox.setPlaceholderText("日志...")

        # MITM 演示（双重加密）
        self.mitmPEdit = QtWidgets.QLineEdit()
        self.mitmCEdit = QtWidgets.QLineEdit()
        self.mitmRadix = QtWidgets.QComboBox()
        self.mitmRadix.addItems(["HEX", "BIN"])
        self.mitmBtn = QtWidgets.QPushButton("运行中间相遇攻击（双重加密）")

        # Layouts — 使用标签页分离 加/解密 与 MITM
        self.tabs = QtWidgets.QTabWidget()

        # --- 加/解密页 ---
        enc_tab = QtWidgets.QWidget()
        enc_form = QtWidgets.QFormLayout(enc_tab)
        enc_form.addRow("密钥 (16/32/48-bit):", self.keyEdit)
        enc_form.addRow("密钥进制:", self.keyMode)
        enc_form.addRow("加密类型:", self.encMode)
        enc_form.addRow("输入模式:", self.inputMode)
        enc_form.addRow("输入:", self.inputText)

        iv_line = QtWidgets.QHBoxLayout()
        iv_line.addWidget(self.ivEdit)
        iv_line.addWidget(self.ivMode)
        iv_line.addWidget(self.ivGenBtn)
        enc_form.addRow("IV (CBC 16-bit):", iv_line)

        buttons = QtWidgets.QHBoxLayout()
        buttons.addWidget(self.encryptBtn)
        buttons.addWidget(self.decryptBtn)
        enc_form.addRow(buttons)

        enc_form.addRow("输出 HEX:", self.outputHex)
        enc_form.addRow("输出 BIN:", self.outputBin)
        enc_form.addRow("输出 ASCII:", self.outputAscii)
        enc_form.addRow(self.verbose)
        enc_form.addRow("日志:", self.logBox)

        # --- MITM 攻击页 ---
        mitm_tab = QtWidgets.QWidget()
        mitm_form = QtWidgets.QFormLayout(mitm_tab)
        mitm_form.addRow(QtWidgets.QLabel("MITM 演示（双重加密）"))
        mitm_form.addRow("进制:", self.mitmRadix)
        mitm_form.addRow("P (16-bit):", self.mitmPEdit)
        mitm_form.addRow("C (16-bit):", self.mitmCEdit)
        mitm_line = QtWidgets.QHBoxLayout()
        mitm_line.addWidget(self.mitmBtn)
        mitm_form.addRow(mitm_line)

        # 多对联合筛选（表格）
        self.mitmPairsTable = QtWidgets.QTableWidget(0, 2)
        self.mitmPairsTable.setHorizontalHeaderLabels(["P", "C"])
        self.mitmPairsTable.horizontalHeader().setStretchLastSection(True)
        self.mitmPairsTable.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.mitmPairsTable.setEditTriggers(QtWidgets.QAbstractItemView.AllEditTriggers)
        self.mitmPairsTable.setFixedHeight(140)
        mitm_form.addRow(QtWidgets.QLabel("多个明密文对（联合筛选）"))
        mitm_form.addRow(self.mitmPairsTable)

        table_ctrls = QtWidgets.QHBoxLayout()
        self.mitmAddRowBtn = QtWidgets.QPushButton("添加行")
        self.mitmDelRowsBtn = QtWidgets.QPushButton("删除所选")
        self.mitmImportBtn = QtWidgets.QPushButton("导入文本")
        self.mitmRunMultiBtn = QtWidgets.QPushButton("运行联合筛选（多对）")
        table_ctrls.addWidget(self.mitmAddRowBtn)
        table_ctrls.addWidget(self.mitmDelRowsBtn)
        table_ctrls.addWidget(self.mitmImportBtn)
        table_ctrls.addStretch(1)
        table_ctrls.addWidget(self.mitmRunMultiBtn)
        mitm_form.addRow(table_ctrls)

        # MITM 日志
        self.mitmLogBox = QtWidgets.QPlainTextEdit()
        self.mitmLogBox.setReadOnly(True)
        self.mitmLogBox.setPlaceholderText("MITM 日志...")
        mitm_form.addRow("日志:", self.mitmLogBox)

        # tabs
        self.tabs.addTab(enc_tab, "加/解密")
        self.tabs.addTab(mitm_tab, "MITM 攻击")

        root = QtWidgets.QVBoxLayout()
        root.addWidget(self.tabs)
        self.setLayout(root)

        # Signals
        self.encryptBtn.clicked.connect(self.encrypt_action)
        self.decryptBtn.clicked.connect(self.decrypt_action)
        self.ivGenBtn.clicked.connect(self.generate_iv)

        self.mitmBtn.clicked.connect(self.mitm_action)
        self.mitmAddRowBtn.clicked.connect(self.add_mitm_row)
        self.mitmDelRowsBtn.clicked.connect(self.del_mitm_rows)
        self.mitmImportBtn.clicked.connect(self.mitm_import_text)
        self.mitmRunMultiBtn.clicked.connect(self.mitm_multi_action)

    # ---------- Helpers ----------
    def get_scheme(self) -> str:
        t = self.encMode.currentText()
        if t.startswith("单重"):
            return 'single'
        if t.startswith("双重"):
            return 'double'
        if "3键" in t:
            return 'triple3'
        return 'triple2'

    def get_keys(self) -> list:
        mode = self.keyMode.currentText()
        scheme = self.get_scheme()
        if scheme == 'single':
            v = parse_key_bits(self.keyEdit.text(), mode, 16)
            return [v]
        elif scheme == 'double' or scheme == 'triple2':
            v = parse_key_bits(self.keyEdit.text(), mode, 32)
            return split_to_16bit_keys(v, 2)
        elif scheme == 'triple3':
            v = parse_key_bits(self.keyEdit.text(), mode, 48)
            return split_to_16bit_keys(v, 3)
        else:
            raise ValueError('未知方案')

    def get_iv(self) -> int:
        return parse_block16(self.ivEdit.text(), self.ivMode.currentText())

    def _append_log(self, s: str):
        self.logBox.appendPlainText(s)

    def generate_iv(self):
        import secrets
        iv = secrets.randbits(16)
        if self.ivMode.currentText() == 'HEX':
            self.ivEdit.setText(f"{iv:04X}")
        else:
            self.ivEdit.setText(f"{iv:016b}")

    def _append_mitm_log(self, s: str):
        self.mitmLogBox.appendPlainText(s)

    # ---------- MITM 表格操作 ----------
    def add_mitm_row(self):
        r = self.mitmPairsTable.rowCount()
        self.mitmPairsTable.insertRow(r)
        self.mitmPairsTable.setItem(r, 0, QtWidgets.QTableWidgetItem(""))
        self.mitmPairsTable.setItem(r, 1, QtWidgets.QTableWidgetItem(""))

    def del_mitm_rows(self):
        sel = self.mitmPairsTable.selectionModel().selectedRows()
        for idx in sorted(sel, key=lambda x: x.row(), reverse=True):
            self.mitmPairsTable.removeRow(idx.row())

    def mitm_import_text(self):
        placeholder = "每行一个P,C (16-bit)；示例:\nHEX: 3A94 1BDA\nBIN: 0011101010010100 0001101111011010\n分隔符支持空格/逗号/冒号/->"
        text, ok = QtWidgets.QInputDialog.getMultiLineText(self, "导入P,C文本", "输入多行：", placeholder)
        if not ok:
            return
        radix = self.mitmRadix.currentText()
        lines = text.strip().splitlines()
        added = 0
        for line in lines:
            s = line.strip()
            if not s:
                continue
            s = s.replace('->', ' ').replace(':', ' ').replace(',', ' ')
            parts = s.split()
            if len(parts) < 2:
                continue
            try:
                p = parse_block16(parts[0], radix)
                c = parse_block16(parts[1], radix)
            except Exception:
                continue
            r = self.mitmPairsTable.rowCount()
            self.mitmPairsTable.insertRow(r)
            self.mitmPairsTable.setItem(r, 0, QtWidgets.QTableWidgetItem(format_block16(p, radix)))
            self.mitmPairsTable.setItem(r, 1, QtWidgets.QTableWidgetItem(format_block16(c, radix)))
            added += 1
        self._append_mitm_log(f"已导入 {added} 行。")

    def get_mitm_pairs_from_table(self):
        pairs = []
        radix = self.mitmRadix.currentText()
        rows = self.mitmPairsTable.rowCount()
        for r in range(rows):
            item_p = self.mitmPairsTable.item(r, 0)
            item_c = self.mitmPairsTable.item(r, 1)
            if not item_p or not item_c:
                continue
            sp = item_p.text().strip()
            sc = item_c.text().strip()
            if not sp or not sc:
                continue
            p = parse_block16(sp, radix)
            c = parse_block16(sc, radix)
            pairs.append((p, c))
        return pairs

    # ---------- Actions ----------
    def encrypt_action(self):
        self.logBox.clear()
        try:
            keys = self.get_keys()
            scheme = self.get_scheme()
            mode = self.inputMode.currentText()

            if "HEX-单块" in mode:
                p = parse_block16(self.inputText.toPlainText(), "HEX")
                log = self._append_log if self.verbose.isChecked() else None
                c = encrypt_with_scheme(p, keys, scheme, log=log)
                self.outputHex.setText(format_block16(c, "HEX"))
                self.outputBin.setText(format_block16(c, "BIN"))
                self.outputAscii.setPlainText(bytes_from_blocks16([c]).decode("latin1", errors="replace"))

            elif "BIN-单块" in mode:
                p = parse_block16(self.inputText.toPlainText(), "BIN")
                log = self._append_log if self.verbose.isChecked() else None
                c = encrypt_with_scheme(p, keys, scheme, log=log)
                self.outputHex.setText(format_block16(c, "HEX"))
                self.outputBin.setText(format_block16(c, "BIN"))
                self.outputAscii.setPlainText(bytes_from_blocks16([c]).decode("latin1", errors="replace"))

            elif "ASCII-多块(ECB" in mode:
                data = self.inputText.toPlainText().encode("utf-8")
                data = pkcs7_pad_2bytes(data)
                blocks = list(blocks16_from_bytes(data))
                log = self._append_log if self.verbose.isChecked() else None
                out_blocks = [encrypt_with_scheme(b, keys, scheme, log=log) for b in blocks]
                out = bytes_from_blocks16(out_blocks)
                self.outputHex.setText(out.hex().upper())
                self.outputBin.setText(' '.join(f"{x:08b}" for x in out))
                try:
                    self.outputAscii.setPlainText(out.decode("utf-8"))
                except:
                    self.outputAscii.setPlainText(out.decode("latin1", errors="replace"))

            else:  # ASCII-多块(CBC,2B)
                data = self.inputText.toPlainText().encode("utf-8")
                data = pkcs7_pad_2bytes(data)
                blocks = list(blocks16_from_bytes(data))
                iv = self.get_iv()
                log = self._append_log if self.verbose.isChecked() else None
                out_blocks = cbc_encrypt_blocks(blocks, keys, scheme, iv, log=log)
                out = bytes_from_blocks16(out_blocks)
                self.outputHex.setText(out.hex().upper())
                self.outputBin.setText(' '.join(f"{x:08b}" for x in out))
                try:
                    self.outputAscii.setPlainText(out.decode("utf-8"))
                except:
                    self.outputAscii.setPlainText(out.decode("latin1", errors="replace"))

        except Exception as e:
            self._append_log(f"[错误] {e}")

    def decrypt_action(self):
        self.logBox.clear()
        try:
            keys = self.get_keys()
            scheme = self.get_scheme()
            mode = self.inputMode.currentText()

            if "HEX-单块" in mode:
                c = parse_block16(self.inputText.toPlainText(), "HEX")
                log = self._append_log if self.verbose.isChecked() else None
                p = decrypt_with_scheme(c, keys, scheme, log=log)
                self.outputHex.setText(format_block16(p, "HEX"))
                self.outputBin.setText(format_block16(p, "BIN"))
                self.outputAscii.setPlainText(bytes_from_blocks16([p]).decode("latin1", errors="replace"))

            elif "BIN-单块" in mode:
                c = parse_block16(self.inputText.toPlainText(), "BIN")
                log = self._append_log if self.verbose.isChecked() else None
                p = decrypt_with_scheme(c, keys, scheme, log=log)
                self.outputHex.setText(format_block16(p, "HEX"))
                self.outputBin.setText(format_block16(p, "BIN"))
                self.outputAscii.setPlainText(bytes_from_blocks16([p]).decode("latin1", errors="replace"))

            elif "ASCII-多块(ECB" in mode:
                txt = self.inputText.toPlainText().strip().replace(' ', '')
                try:
                    if len(txt) % 2 != 0:
                        raise ValueError("HEX长度须为偶数")
                    raw = bytes.fromhex(txt)
                except Exception:
                    raw = txt.encode("utf-8")
                if len(raw) % 2 == 1:
                    raw = raw + b'\x00'
                blocks = list(blocks16_from_bytes(raw))
                log = self._append_log if self.verbose.isChecked() else None
                out_blocks = [decrypt_with_scheme(b, keys, scheme, log=log) for b in blocks]
                out = bytes_from_blocks16(out_blocks)
                out = pkcs7_unpad_2bytes(out)
                self.outputHex.setText(out.hex().upper())
                self.outputBin.setText(' '.join(f"{x:08b}" for x in out))
                try:
                    self.outputAscii.setPlainText(out.decode("utf-8"))
                except:
                    self.outputAscii.setPlainText(out.decode("latin1", errors="replace"))

            else:  # ASCII-多块(CBC,2B)
                txt = self.inputText.toPlainText().strip().replace(' ', '')
                try:
                    if len(txt) % 2 != 0:
                        raise ValueError("HEX长度须为偶数")
                    raw = bytes.fromhex(txt)
                except Exception:
                    raw = txt.encode("utf-8")
                if len(raw) % 2 == 1:
                    raw = raw + b'\x00'
                blocks = list(blocks16_from_bytes(raw))
                iv = self.get_iv()
                log = self._append_log if self.verbose.isChecked() else None
                out_blocks = cbc_decrypt_blocks(blocks, keys, scheme, iv, log=log)
                out = bytes_from_blocks16(out_blocks)
                out = pkcs7_unpad_2bytes(out)
                self.outputHex.setText(out.hex().upper())
                self.outputBin.setText(' '.join(f"{x:08b}" for x in out))
                try:
                    self.outputAscii.setPlainText(out.decode("utf-8"))
                except:
                    self.outputAscii.setPlainText(out.decode("latin1", errors="replace"))

        except Exception as e:
            self._append_log(f"[错误] {e}")

    def mitm_action(self):
        try:
            radix = self.mitmRadix.currentText()
            p = parse_block16(self.mitmPEdit.text(), radix)
            c = parse_block16(self.mitmCEdit.text(), radix)
            self._append_mitm_log("开始 MITM 攻击（双重加密），可能需要数秒...")
            results = meet_in_the_middle_double(p, c, log=self._append_mitm_log)
            if results:
                preview = "\n".join([f"K1={k1:04X} K2={k2:04X}" for (k1, k2) in results[:10]])
                self._append_mitm_log("候选(前10):\n" + preview)
                self._append_mitm_log("如需唯一确定，请在下方表格添加更多(P,C)进行联合筛选。")
            else:
                self._append_mitm_log("未找到候选，检查输入或提供更多已知对。")
        except Exception as e:
            self._append_mitm_log(f"[错误] MITM: {e}")

    def parse_mitm_pairs_text(self):
        radix = self.mitmRadix.currentText()
        lines = self.mitmPairsEdit.toPlainText().strip().splitlines()
        pairs = []
        for line in lines:
            s = line.strip()
            if not s:
                continue
            s = s.replace('->', ' ').replace(':', ' ').replace(',', ' ')
            parts = s.split()
            if len(parts) < 2:
                continue
            p = parse_block16(parts[0], radix)
            c = parse_block16(parts[1], radix)
            pairs.append((p, c))
        return pairs

    def mitm_multi_action(self):
        try:
            pairs = self.get_mitm_pairs_from_table()
            if not pairs:
                self._append_mitm_log("请在表格中至少填入一行 P 与 C。")
                return
            self._append_mitm_log(f"开始 MITM 联合筛选（{len(pairs)} 个对）...")
            results = meet_in_the_middle_double_multi(pairs, log=self._append_mitm_log)
            if results:
                preview = "\n".join([f"K1={k1:04X} K2={k2:04X}" for (k1, k2) in results[:10]])
                self._append_mitm_log("最终候选(前10):\n" + preview)
                self._append_mitm_log(f"候选总数: {len(results)}")
            else:
                self._append_mitm_log("联合筛选后无候选，请检查输入或增加更多对。")
        except Exception as e:
            self._append_mitm_log(f"[错误] MITM-联合筛选: {e}")


def main():
    app = QtWidgets.QApplication(sys.argv)
    w = SAESWindow()
    w.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
